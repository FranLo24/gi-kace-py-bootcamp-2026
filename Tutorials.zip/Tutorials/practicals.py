
li = [1,2,3]
li.append(4)
li